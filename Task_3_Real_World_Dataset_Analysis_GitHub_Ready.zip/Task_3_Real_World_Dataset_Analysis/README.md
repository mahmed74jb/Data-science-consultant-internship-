# Task 3 — Real-World Dataset Analysis Project

## Business question
What patterns in customer and campaign data are associated with term-deposit subscriptions, and how can they inform future campaign planning?

## Dataset
UCI Machine Learning Repository — Bank Marketing: https://archive.ics.uci.edu/dataset/222/bank+marketing

The notebook downloads the official archive at runtime and loads `bank-full.csv`. If internet access is unavailable, download the file from UCI and place `bank-full.csv` in the notebook's working directory.

## Project contents
- `notebook/Task_3_Real_World_Dataset_Analysis.ipynb` — reproducible analysis workflow.
- `report/Task_3_Real_World_Dataset_Analysis_Report.docx` — standalone submission report.
- `outputs/analysis_workflow.png` — workflow overview.
- `requirements.txt` — dependencies.

## Run the analysis
1. Install Python 3.10 or newer.
2. Run `pip install -r requirements.txt`.
3. Open the notebook in Jupyter or Google Colab.
4. Execute all cells from top to bottom.
5. Review the computed tables and charts in `outputs/`.

## Interpretation
The analysis is exploratory and descriptive. It does not prove causal relationships or build a predictive model. Dataset-specific results are generated when the notebook is executed; review actual outputs before quoting numerical findings.
