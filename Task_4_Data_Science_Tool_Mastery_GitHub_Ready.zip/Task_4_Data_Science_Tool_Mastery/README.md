# Task 4 — Data Science Tool Mastery
A reproducible Jupyter project using the UCI Bank Marketing dataset.
Tools: Python, Jupyter, pandas, NumPy, Matplotlib, Seaborn, scikit-learn and joblib.
Run `pip install -r requirements.txt`, then open `notebook/Task_4_Data_Science_Tool_Mastery.ipynb` and run all cells.
The notebook downloads the official dataset and saves charts, metrics, predictions and the fitted pipeline in `outputs/`.
`duration` is excluded because it is post-call information and would leak information into a pre-call targeting model.
