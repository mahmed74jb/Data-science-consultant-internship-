# Task 1 — Data Science Fundamentals Assessment

**Student:** Muhammad Ahmed  
**Internship:** Data Science Consultant  
**Dataset:** UCI Bank Marketing (`bank-full.csv`)

## Objective
Explore a real-world marketing dataset using Python fundamentals, data quality checks, descriptive statistics, and exploratory data analysis.

## Dataset
The legacy Bank Marketing file contains 45,211 records and 17 columns. Target `y` indicates whether a client subscribed to a term deposit. Published target counts: no=39,922; yes=5,289. Dataset source: https://archive.ics.uci.edu/dataset/222/bank+marketing

## Project contents
- `report/Task_1_Data_Science_Fundamentals_Assessment_Report.docx` — Word report
- `notebook/Task_1_Data_Science_Fundamentals_Assessment.ipynb` — reproducible notebook
- `outputs/target_class_distribution.png` — target distribution chart
- `requirements.txt` — Python packages

## Run
Install requirements, open the notebook in Jupyter, and run cells in order. The notebook downloads the official UCI archive and locates `bank-full.csv` automatically. Internet access is required for the first run.

## Method notes
- Exact duplicate rows are counted before removal.
- `unknown` category labels are not automatically treated as missing values.
- `pdays = -1` is a special code for no previous contact.
- `duration` is post-contact information and should not be used in a pre-call targeting model.
- Outlier flags are diagnostic only and do not automatically delete records.

## Citation
Moro, S., Rita, P., & Cortez, P. (2014). Bank Marketing [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5K306
