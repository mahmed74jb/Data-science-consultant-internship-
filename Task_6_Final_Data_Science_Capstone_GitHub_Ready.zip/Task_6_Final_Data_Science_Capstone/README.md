# Task 6 — Final Data Science Capstone Project

## Project
Bank Marketing Subscription Prediction and Campaign Decision Support.

## Contents
- `notebook/`: end-to-end Jupyter capstone.
- `report/`: separate capstone report for internship submission.
- `requirements.txt`: Python dependencies.
- `outputs/`: generated artifacts will be written here when the notebook runs.

## Run
```bash
pip install -r requirements.txt
jupyter notebook notebook/Task_6_Final_Data_Science_Capstone.ipynb
```
Run all cells from top to bottom. The notebook downloads the official UCI Bank Marketing archive at runtime.

## Methodology notes
- Target: `y` (term-deposit subscription).
- `duration` is excluded because it is only known after the current call and would leak post-call information into a pre-call targeting model.
- Preprocessing is kept inside scikit-learn pipelines.
- Cross-validation compares candidate models on training data; the held-out test set is reserved for final evaluation.
- Actual metrics and charts are generated at runtime. This package does not claim that unexecuted results have already been measured.
