# Task 2 — Hands-On Data Lab Implementation

This repository contains the practical notebook and supporting documentation for Task 2 of the Data Science Consultant internship.

## Dataset
UCI Machine Learning Repository — Bank Marketing  
https://archive.ics.uci.edu/dataset/222/bank+marketing

The notebook downloads the official archive at runtime and loads `bank-full.csv`. If network access is unavailable, download the archive from the UCI page and put `bank-full.csv` in the notebook's working directory.

## Contents
- `notebook/Task_2_Hands_On_Data_Lab_Implementation.ipynb` — environment setup, data loading, inspection, cleaning, Pandas manipulation, statistics, and visualizations.
- `report/Task_2_Hands_On_Data_Lab_Report.docx` — standalone submission report.
- `outputs/data_lab_workflow.png` — overview of the workflow.
- `requirements.txt` — Python dependencies.

## Run
1. Create/activate a Python environment.
2. Install dependencies: `pip install -r requirements.txt`
3. Open the notebook in Jupyter or Google Colab.
4. Run cells from top to bottom.
5. Generated CSV summaries and chart images will be saved in `outputs/`.

## Notes
The notebook computes dataset-specific outputs when executed. Do not report calculated values until the notebook has been run and its outputs reviewed. The analysis is descriptive; it does not establish causal relationships.
