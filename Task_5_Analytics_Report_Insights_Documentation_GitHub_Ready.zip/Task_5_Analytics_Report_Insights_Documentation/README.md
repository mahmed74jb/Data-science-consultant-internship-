# Task 5 — Analytics Report & Insights Documentation
Reproducible descriptive analytics using the UCI Bank Marketing dataset.
Run `pip install -r requirements.txt`, then open the notebook and run all cells.
It generates data-quality checks, outcome summaries, segment analysis, campaign-contact analysis, charts, and a text file of dataset-specific insights in `outputs/`.
All figures and numeric findings are calculated at runtime. Interpretations are descriptive, not causal.
